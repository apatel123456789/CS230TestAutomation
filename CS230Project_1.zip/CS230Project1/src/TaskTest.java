
import org.junit.Test;

public class TaskTest {

  @Test public void createValidTaskData() {
      Task task = new Task("01", "ReadingTest", "Read Testing");
      System.out.println(task);
   }
   
}